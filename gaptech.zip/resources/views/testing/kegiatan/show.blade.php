
<a href="{{route('kegiatan.edit',$kegiatan->id)}}">Edit</a>

{{$kegiatan}}

<img src="{{url('public/Image/'.$kegiatan->foto_kegiatan)}}"/>