
<a href="{{route('galeri.edit',$galeri->id)}}">Edit</a>

{{$galeri}}

<img src="{{url('public/Image/'.$galeri->foto_galeri)}}"/>