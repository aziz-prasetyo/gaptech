
<a href="{{route('artikel.edit',$artikel->id)}}">Edit</a>

{{$artikel}}

<img src="{{url('public/Image/'.$artikel->foto_artikel)}}"/>