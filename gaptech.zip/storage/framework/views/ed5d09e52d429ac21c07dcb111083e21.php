<?php if (isset($component)) { $__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5 = $component; } ?>
<?php $component = App\View\Components\LandingPageLayout::resolve(['artikel' => $artikel,'galeri' => $galeri] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-page-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LandingPageLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <main class="pt-8 pb-16 mt-[72px] antialiased bg-white lg:pt-16 lg:pb-24 dark:bg-gray-900">
        <div class="flex justify-between max-w-screen-xl px-4 mx-auto ">
            <article
                class="w-full max-w-2xl mx-auto format format-sm sm:format-base lg:format-lg format-blue dark:format-invert">
                <header class="mb-4 lg:mb-6 not-format">
                    <!-- <address class="flex items-center mb-6 not-italic">
                        <div class="inline-flex items-center mr-3 text-sm text-gray-900 dark:text-white">
                            <img class="w-16 h-16 mr-4 rounded-full"
                                src="https://flowbite.com/docs/images/people/profile-picture-2.jpg" alt="Jese Leos">
                            <div>
                                <a href="#" rel="author"
                                    class="text-xl font-bold text-gray-900 dark:text-white">Jese Leos</a>
                                <p class="text-base text-gray-500 dark:text-gray-400">Graphic Designer, educator & CEO
                                    Flowbite</p>
                                <p class="text-base text-gray-500 dark:text-gray-400"><time pubdate
                                        datetime="2022-02-08" title="February 8th, 2022">Feb. 8, 2022</time></p>
                            </div>
                        </div>
                    </address> -->
                    <h1
                        class="mb-4 text-3xl font-extrabold leading-tight text-gray-900 lg:mb-6 lg:text-4xl dark:text-white">
                        <?php echo e($artikel->judul); ?></h1>
                </header>
                <figure><img src="<?php echo e(URL('public/Image/'.$artikel->foto_artikel)); ?>"
                        alt="">
                    <figcaption>Foto Ilustrasi</figcaption>
                </figure>
                <p class="lead"><?php echo e($artikel->isi_artikel); ?></p>
            </article>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5)): ?>
<?php $component = $__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5; ?>
<?php unset($__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5); ?>
<?php endif; ?>
<?php /**PATH C:\Kerjaan\lansia-2\komunitas-lansia-app\resources\views/artikel/detail-example.blade.php ENDPATH**/ ?>