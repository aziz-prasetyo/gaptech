<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 flex flex-wrap gap-6 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <a href="<?php echo e(route('artikel.index')); ?>" class="p-12 w-[45%] flex flex-col items-center rounded-xl bg-white">
                <h1 class="text-6xl"><?php echo e($artikelCount ? $artikelCount : 0); ?></h1>
                <p>Total Artikel</p>
            </a>
            <a href="<?php echo e(route('galeri.index')); ?>" class="p-12 w-[45%] flex flex-col items-center rounded-xl bg-white">
                <h1 class="text-6xl"><?php echo e($galeriCount ? $galeriCount : 0); ?></h1>
                <p>Total Galeri</p>
            </a>
            <a href="<?php echo e(route('kontak.index')); ?>" class="p-12 w-[45%] flex flex-col items-center rounded-xl bg-white">
                <h1 class="text-6xl"><?php echo e($pesanCount ? $pesanCount : 0); ?></h1>
                <p>Total Pojok Curhat</p>
            </a>
            <a href="<?php echo e(route('calonanggota.index')); ?>" class="p-12 w-[45%] flex flex-col items-center rounded-xl bg-white">
                <h1 class="text-6xl"><?php echo e($calonanggotaCount ? $calonanggotaCount : 0); ?></h1>
                <p>Total Calon Anggota</p>
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Kerjaan\lansia-2\komunitas-lansia-app\resources\views/dashboard.blade.php ENDPATH**/ ?>