<?php if (isset($component)) { $__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1dd0ed6bfebd06e839baf9f08ff82fc5 = $attributes; } ?>
<?php $component = App\View\Components\LandingPageLayout::resolve(['artikel' => $artikel,'galeri' => $galeri] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-page-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LandingPageLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal8fceea5439af2ace89bc97b271047a4e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fceea5439af2ace89bc97b271047a4e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-page.sections.hero','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-page.sections.hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fceea5439af2ace89bc97b271047a4e)): ?>
<?php $attributes = $__attributesOriginal8fceea5439af2ace89bc97b271047a4e; ?>
<?php unset($__attributesOriginal8fceea5439af2ace89bc97b271047a4e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fceea5439af2ace89bc97b271047a4e)): ?>
<?php $component = $__componentOriginal8fceea5439af2ace89bc97b271047a4e; ?>
<?php unset($__componentOriginal8fceea5439af2ace89bc97b271047a4e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal04a83fed8288b26999114843e52e57c8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04a83fed8288b26999114843e52e57c8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-page.sections.about','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-page.sections.about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04a83fed8288b26999114843e52e57c8)): ?>
<?php $attributes = $__attributesOriginal04a83fed8288b26999114843e52e57c8; ?>
<?php unset($__attributesOriginal04a83fed8288b26999114843e52e57c8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04a83fed8288b26999114843e52e57c8)): ?>
<?php $component = $__componentOriginal04a83fed8288b26999114843e52e57c8; ?>
<?php unset($__componentOriginal04a83fed8288b26999114843e52e57c8); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalbffebf0b692e88327c03ce1fa4e048d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbffebf0b692e88327c03ce1fa4e048d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-page.sections.article','data' => ['artikel' => $artikel]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-page.sections.article'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['artikel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($artikel)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbffebf0b692e88327c03ce1fa4e048d6)): ?>
<?php $attributes = $__attributesOriginalbffebf0b692e88327c03ce1fa4e048d6; ?>
<?php unset($__attributesOriginalbffebf0b692e88327c03ce1fa4e048d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbffebf0b692e88327c03ce1fa4e048d6)): ?>
<?php $component = $__componentOriginalbffebf0b692e88327c03ce1fa4e048d6; ?>
<?php unset($__componentOriginalbffebf0b692e88327c03ce1fa4e048d6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal808442c2d4488d541fe231b3c0a5b508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal808442c2d4488d541fe231b3c0a5b508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-page.sections.gallery','data' => ['galeri' => $galeri]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-page.sections.gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['galeri' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($galeri)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal808442c2d4488d541fe231b3c0a5b508)): ?>
<?php $attributes = $__attributesOriginal808442c2d4488d541fe231b3c0a5b508; ?>
<?php unset($__attributesOriginal808442c2d4488d541fe231b3c0a5b508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal808442c2d4488d541fe231b3c0a5b508)): ?>
<?php $component = $__componentOriginal808442c2d4488d541fe231b3c0a5b508; ?>
<?php unset($__componentOriginal808442c2d4488d541fe231b3c0a5b508); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalad833506d64021ce424c7c497af5ebd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad833506d64021ce424c7c497af5ebd2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-page.sections.contact','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-page.sections.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad833506d64021ce424c7c497af5ebd2)): ?>
<?php $attributes = $__attributesOriginalad833506d64021ce424c7c497af5ebd2; ?>
<?php unset($__attributesOriginalad833506d64021ce424c7c497af5ebd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad833506d64021ce424c7c497af5ebd2)): ?>
<?php $component = $__componentOriginalad833506d64021ce424c7c497af5ebd2; ?>
<?php unset($__componentOriginalad833506d64021ce424c7c497af5ebd2); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1dd0ed6bfebd06e839baf9f08ff82fc5)): ?>
<?php $attributes = $__attributesOriginal1dd0ed6bfebd06e839baf9f08ff82fc5; ?>
<?php unset($__attributesOriginal1dd0ed6bfebd06e839baf9f08ff82fc5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5)): ?>
<?php $component = $__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5; ?>
<?php unset($__componentOriginal1dd0ed6bfebd06e839baf9f08ff82fc5); ?>
<?php endif; ?>
<?php /**PATH D:\Documents\Projects\Gaptech\komunitas-lansia-app\komunitas-lansia-app\resources\views/home.blade.php ENDPATH**/ ?>