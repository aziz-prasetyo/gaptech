<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['imagePath']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['imagePath']); ?>
<?php foreach (array_filter((['imagePath']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $cacheKey = 'cached_image_' . md5($imagePath);
?>

<?php if(Cache::has($cacheKey)): ?>
    <img src="<?php echo e(Cache::get($cacheKey)); ?>" <?php echo e($attributes); ?>>
<?php else: ?>
    <?php
        $imageContents = file_get_contents(public_path($imagePath));
        Cache::put($cacheKey, 'data:image/png;base64,' . base64_encode($imageContents), now()->addHours(6));
    ?>
    <img src="<?php echo e(Cache::get($cacheKey)); ?>" <?php echo e($attributes); ?>>
<?php endif; ?>
<?php /**PATH C:\Kerjaan\lansia-2\komunitas-lansia-app\resources\views/components/cached-image.blade.php ENDPATH**/ ?>